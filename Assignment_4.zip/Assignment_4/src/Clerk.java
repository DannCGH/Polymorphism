public class Clerk extends Employee{

    public Clerk(int employeeID, String name, String department, double salary, String designation) {
        super(employeeID, name, department, salary, designation);
    }

    public double addBonus(double salary){
        setSalary(salary + 100);
        return (getSalary());
    }
}
