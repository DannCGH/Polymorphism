public class Manager extends Employee {
    public Manager(int employeeID, String name, String department, double salary, String designation) {
        super(employeeID, name, department, salary, designation);
    }

    public double addBonus(double salary){
        setSalary(salary + 300);
        return (getSalary());
    }

}
