import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Manager employee1 = new Manager(001, "Mark", "HR", 15000.0, "Manager");
        Manager.display(employee1);

        Manager employee2 = new Manager(12, "Peter", "R&D", 15000.0, "Manager");
        Manager.display(employee2);

        Clerk employee3 = new Clerk(56, "Samual", "Accounts", 10000.0, "Clerk");
        Clerk.display(employee3);

        Employee employee4 = new Employee(89, "???", "???", 10000.0, "???");

        employee1.equals(employee3);

        System.out.println();

        for (int i = 0; i < 4; i++) {
            Scanner scanner = new Scanner(System.in);
            switch(i){
                case 0:
                    System.out.printf("Enter the number of days Employee E%03d is Present out of 20 :", employee1.getEmployeeID());
                    String input1 = scanner.next();
                    try {
                        int intInput = Integer.parseInt(input1);
                        if (intInput >= 0 && intInput <= 20){
                            employee1.salaryDeduction(intInput);
                        } else {
                            System.out.println("Invalid Input. Please try again.");
                            i--;
                        }
                    } catch (NumberFormatException nfe) {
                        System.out.println("Invalid Input. Please try again.");
                        i--;
                    }
                    break;
                case 1:
                    System.out.printf("Enter the number of days Employee E%03d is Present out of 20 :", employee2.getEmployeeID());
                    String input2 = scanner.next();
                    try {
                        int intInput = Integer.parseInt(input2);
                        if (intInput >= 0 && intInput <= 20){
                            employee2.salaryDeduction(intInput);
                        } else {
                            System.out.println("Invalid Input. Please try again.");
                            i--;
                        }
                    } catch (NumberFormatException nfe) {
                        System.out.println("Invalid Input. Please try again.");
                        i--;
                    }
                    break;
                case 2:
                    System.out.printf("Enter the number of days Employee E%03d is Present out of 20 :", employee3.getEmployeeID());
                    String input3 = scanner.next();
                    try {
                        int intInput = Integer.parseInt(input3);
                        if (intInput >= 0 && intInput <= 20){
                            employee3.salaryDeduction(intInput);
                        } else {
                            System.out.println("Invalid Input. Please try again.");
                            i--;
                        }
                    } catch (NumberFormatException nfe) {
                        System.out.println("Invalid Input. Please try again.");
                        i--;
                    }
                    break;
                case 3:
                    System.out.printf("Enter the number of days Employee E%03d is Present out of 20 :", employee4.getEmployeeID());
                    String input4 = scanner.next();
                    try {
                        int intInput = Integer.parseInt(input4);
                        if (intInput >= 0 && intInput <= 20){
                            employee4.salaryDeduction(intInput);
                        } else {
                            System.out.println("Invalid Input. Please try again.");
                            i--;
                        }
                    } catch (NumberFormatException nfe) {
                        System.out.println("Invalid Input. Please try again.");
                        i--;
                    }
                    break;
            }
        }

        System.out.println();

        System.out.println("Employee ID \tPresent Absent\tDeductions");
        System.out.printf("E%03d\t\t\t" + employee1.getDaysPresent() + "\t\t" +  (20 - employee1.getDaysPresent()) + "\t\t$" + employee1.getDeduction() + "\n", employee1.getEmployeeID());
        System.out.printf("E%03d\t\t\t" + employee2.getDaysPresent() + "\t\t" +  (20 - employee2.getDaysPresent()) + "\t\t$" + employee2.getDeduction() + "\n", employee2.getEmployeeID());
        System.out.printf("E%03d\t\t\t" + employee3.getDaysPresent() + "\t\t" +  (20 - employee3.getDaysPresent()) + "\t\t$" + employee3.getDeduction() + "\n", employee3.getEmployeeID());
        System.out.printf("E%03d\t\t\t" + employee4.getDaysPresent() + "\t\t" +  (20 - employee4.getDaysPresent()) + "\t\t$" + employee4.getDeduction() + "\n", employee4.getEmployeeID());

        System.out.println();
        System.out.println(" Total Deductions : " + (employee1.getDeduction() + employee2.getDeduction() + employee3.getDeduction() + employee4.getDeduction()));
    }
}