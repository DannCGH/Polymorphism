public class Employee {
    private int employeeID;
    private String name;
    private String department;
    private double salary;
    private String designation;
    private double deduction;
    private int daysPresent;

    public Employee(int employeeID, String name, String department, double salary, String designation){
        setEmployeeID(employeeID);
        setName(name);
        setDepartment(department);
        setSalary(salary);
        setDesignation(designation);
    }

    public int getEmployeeID() {
        return employeeID;
    }

    public String getName() {
        return name;
    }

    public String getDepartment() {
        return department;
    }

    public double getSalary() {
        return salary;
    }

    public String getDesignation() {
        return designation;
    }

    public double getDeduction() {
        return deduction;
    }

    public int getDaysPresent() {
        return daysPresent;
    }

    public void setEmployeeID(int employeeID) {
        this.employeeID = employeeID;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public void setDeduction(double deduction) {
        this.deduction = deduction;
    }

    public void setDaysPresent(int daysPresent) {
        this.daysPresent = daysPresent;
    }

    public void equals(Employee other){
        if (getDesignation().equals(other.getDesignation())){
            System.out.println(name + " and " + other.name + " have the same Designation");
        } else {
            System.out.println(name + " and " + other.name + " have different Designations");
        }
    }


    public double addBonus(double salary){
        setSalary(salary + 200);
        return (getSalary());
    }

    public void salaryDeduction(int days){
        setDaysPresent(days);
        setDeduction((getSalary() * (20 - days)) / 20);
    }

    public static void display(Employee employee){
        System.out.printf("Employee ID :E%03d" + "\n", employee.employeeID);
        System.out.println("Employee name : " + employee.name);
        System.out.println("Department name : " + employee.department);
        System.out.println("Salary :" + employee.salary);
        System.out.println("Designation : " + employee.designation);
        System.out.println("Salary after adding the bonus is : " + employee.addBonus(employee.salary));
        System.out.println();
    }
}
